import os
import shutil

import os.path

def ignorePath(path):
  def ignoref(directory, contents):
    return (f for f in contents if os.abspath(os.path.join(directory, f)) == path)
  return ignoref

for r, d, f in os.walk(os.path.join(os.getcwd(),'prompts-and-testbenches/')):
    for dir in d:
        if(dir.startswith("examples")):
            dir_path=os.path.join(r,dir)
            shutil.rmtree(dir_path)
    # for file in f:
    #     if(file=="examples.json" or file.startswith("master_examples")):
    #         os.remove( os.path.join(r,file) )

