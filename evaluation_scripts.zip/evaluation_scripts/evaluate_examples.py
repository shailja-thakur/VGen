import os
import pdb
from pathlib import Path
import subprocess
import shutil

# get the example directories
example_dirs = []
base_dir = os.path.join(os.getcwd(),"prompts-and-testbenches/")
# r=root, d=directories, f = files
for r, d, f in os.walk(base_dir):
    for dir in d:
        if (dir.startswith("examples" )):
            example_dirs.append(os.path.join(r,dir))

# for each example directory, 
for example_dir in example_dirs:

    print("working on example dir: ", example_dir)

    num_compiled=0
    num_functionaly_correct=0
    
    # if there is no results directory, create it
    results_dir = os.path.join(example_dir, "results" )
    if not os.path.isdir(results_dir):
        os.mkdir(results_dir)

    # create files to record files that compile correctly and are functionally correct
    filename_results_compiled =  "results_compiled.txt"
    filename_results_tb_passed=  "results_tb_passed.txt"
    fw_compiled=open( os.path.join(results_dir,filename_results_compiled),'w' )
    fw_tb_passed=open( os.path.join(results_dir,filename_results_tb_passed),'w' )

    # gather example files
    example_paths = []
    for r, d, f in os.walk(example_dir):
        for file in f:
            if (file.startswith("example") and file.endswith(".v")):
                example_paths.append(os.path.join(r,file))
    
    # get testbench file
    p = Path(example_dir)
    prompt_dir = p.parent
    for r, d, f in os.walk(prompt_dir):
        for file in f:
            if (file.startswith("tb")):
                tb = (os.path.join(r,file))

    # for each example
        #  if there is no error while compiling program, add it to results_compiled.txt  
            #  if testbench passes while running program, add it to results_tb_passed.txt
    for example in example_paths:
        print("working on example: ", example)
        result = subprocess.run(['iverilog','-o','example',example,tb], stderr=subprocess.PIPE).stderr.decode('utf-8')
        if(len(result)==0):
            fw_compiled.write(example)
            fw_compiled.write('\n')
            
            result = subprocess.run(['vvp','example'], stdout=subprocess.PIPE).stdout.decode('utf-8')
            if(result[-17:]=="all tests passed\n"):
                fw_tb_passed.write(example)
                fw_tb_passed.write('\n')

    fw_compiled.close()
    fw_tb_passed.close()
