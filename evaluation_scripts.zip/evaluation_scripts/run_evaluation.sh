#!/bin/bash

script="run_evaluation.sh"

function usage {
  # specifies the script's usage
  echo -e "usage: $ sh $script [-m <model>] [-n <iterations>] [-i <IP>] [-p <port>] [-t <max_token_length>] [-o <output_dir>] [-k <model_type>] [-h|--help]\n"
}

function help {
  usage

  # echo -e "MANDATORY:"
  # echo -e "\t -n                          specifies the name\n"
  echo -e "OPTIONAL:"
  echo -e "\t -m          Specifies the model {code-davinci-002,LMMegatron_345,codegen_16B,codegen_6B,codegen_2B,gpt_117M}"
  echo -e "\t -k	  Specifies type of model {ft-finetuned/pt-pretrained}"
  echo -e "\t -t          specifies the maximum length of generated tokens"
  echo -e "\t -o          specifies the save directory"
  echo -e "\t -i          specifies the IP address of the host fauxpilot"
  echo -e "\t -p                          specifies the port running fauxpilot"
  echo -e "\t -n                          specifies whether this person is currently alive"
  # echo -e "\t -d                          debug-mode: logging enabled"
  echo -e "\t -h, --help                  prints this help\n"
}

function return_help {
  # find command-line argument 'help' or 'h' and return help, exit script
  for argument in "$@"
  do
    if [[ $argument == "--help" ]] || [[ $argument == "-h" ]]; then
      help
      exit
    fi
  done
}

# initialize all mandatory and optional arguments from command-line
while getopts :t:i:p:n:o:m:k: flag
do
  case "${flag}" in
    t) max_token_length=${OPTARG};;
    i) ip=${OPTARG};;
    p) port=${OPTARG};;
    n) n=${OPTARG};;
    o) output_dir=${OPTARG};;
    m) model=${OPTARG};;
    k) model_kind=${OPTARG};;
    \? ) usage;;
  esac
done

if [[ $# -eq 0 ]]; then
  # no command-line arguments OR $name missing, show usage and exit
  usage
  exit
fi

# look for --help or -h CLA and return help statement
return_help "$@"

# instantiate our keyword arguments for run.py
run_py_args="--ip $ip "

if [[ ${max_token_length} ]]; then
  run_py_args+="--max_token_length $max_token_length "
fi

if [[ ${port} ]]; then
  run_py_args+="--port $port "
fi

if [[ ${n} ]]; then
  run_py_args+="--n $n "
fi

if [[ ${output_dir} ]]; then
  run_py_args+="--output_dir $output_dir "
fi

if [[ ${model} ]]; then
  run_py_args+="--model $model "
fi

if [[ ${model_kind} ]]; then
  run_py_args+="--model_kind $model_kind "
fi

echo "$run_py_args"

# if [[ -z ${debug} ]]; then
#   # no debug supplied with arg [-d]
#   run_py_args+="--debug False"
# else
#   run_py_args+="--debug True"
# fi

CURRENT_DIR=$(pwd)
cd $CURRENT_DIR
echo "$CURRENT_DIR"
echo "$output_dir"

if [[ "${output_dir}" ]]; then 
	#read -p "Are you sure you want to remove the example files? <y/N> " prompt
	prompt=y
	if [[ $prompt == "y" || $prompt == "Y" || $prompt == "yes" || $prompt == "Yes" ]]; then
		echo "Removing the temporary files"
		python remove_all.py
	else
		exit 0
	fi
fi

if [[ ! -d results ]]; then
	mkdir $(pwd)/evaluation
fi

OUT_PATH=$(pwd)/evaluation/$output_dir

echo "$ python gen_examples_all.py $run_py_args"
python gen_examples_all.py $run_py_args
# python gen_examples_all.py --max_token_length 200 --ip 128.238.147.64 --port 5000  --n 1

python evaluate_examples.py 

python get_results.py $n $model

if [[ ! -z "${output_dir}" ]]; then
	echo "Saving results to $OUT_PATH"
  python copy_results.py $OUT_PATH
  
  echo "Removing the temporary files"
  python remove_all.py 
fi

RESULT_FILE=$(pwd)/"results.csv"
echo "$RESULT_FILE"
if [[ -f $RESULT_FILE ]]; then
  echo "Moving results.csv file to $output_dir"
  mv $RESULT_FILE $(pwd)/evaluation/$output_dir
fi
