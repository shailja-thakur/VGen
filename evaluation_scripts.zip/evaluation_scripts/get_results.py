import os
import pdb
from pathlib import Path
import subprocess
import shutil
import sys
# results summary
# prompt,llm,temp, #compiled, #tb_passed, total
fw_results=open( "results.csv",'w' )
fw_results.write("prompt,llm,temp,#compiled,#tb_passed,total")
fw_results.write('\n')


# example directories
N=sys.argv[1]
prompts=["basic1","basic2","basic3","basic4","intermediate1","intermediate2","intermediate3","intermediate4","advanced1","advanced2","advanced3","advanced4","intermediate5","intermediate6","advanced5"]

prompts=["advanced5"]
#llm = "code-gen-16B" # llm is varied on the remote server, not in this script
llm=sys.argv[2]
temp = [0.1,0.3,0.5,0.7,1]

for prompt in prompts:
    prompt_dir = os.path.join(os.getcwd(),"prompts-and-testbenches",prompt)
    for t in temp:
        examples_dir_name="examples-" + llm + "-tmp_" + str(t)
        examples_path=os.path.join(prompt_dir,examples_dir_name)
        results_path=os.path.join(prompt_dir,examples_dir_name,"results")
        results_compiled=os.path.join(results_path,"results_compiled.txt")
        results_tb_passed=os.path.join(results_path,"results_tb_passed.txt")
        num_compiled=sum(1 for line in open(results_compiled))
        num_tb_passed=sum(1 for line in open(results_tb_passed))
        line=prompt+","+llm+","+str(t)+","+str(num_compiled)+","+str(num_tb_passed)+","+str(N)
        fw_results.write(line)
        fw_results.write('\n')

fw_results.close()
