#!/bin/bash

MODEL=codegen_2B  #{LMMegatron_345M, codegen_16B,codegen_6B,codegen_2B,gpt_117M,gptneo_2.7,code-davinci-002}
MODEL_TYPE=ft          #{pretrianed(pt)/finetuned(ft)}
TOKENS=200
PORT=5000
# get ip addres mapped to hostname
HOST=arrakis           #{arrakis, sg03}

# strips the IP
hostname=${HOST}.poly.edu
IP=$( host ${hostname} | sed -e "s/.*\ //" )

# checks for errors
if [ $? -ne 0 ] ; then
   echo "Error: cannot resolve ${hostname}" 1>&2
   exit 1;
fi

# Pass@k
for k in 1 10 20; do

	OUT_DIR=all_results_${MODEL}_${MODEL_TYPE}_n${k}
	echo $OUT_DIR

	bash run_evaluation.sh -n ${k} -i $IP -p $PORT -t $TOKENS -o $OUT_DIR -m $MODEL -k $MODEL_TYPE
	
done
