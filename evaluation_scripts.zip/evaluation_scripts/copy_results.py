import os
import shutil
import errno
import sys
from distutils.dir_util import copy_tree
filename=sys.argv[1]
dst=os.path.join(os.getcwd(),filename)
print(dst)
try:
    #if path already exists, remove it before copying with copytree()
    if os.path.exists(dst):
        #print(dst)
        shutil.rmtree(dst)
    for r, d, f in os.walk(os.getcwd()):
        #print(f)
        for dir in d:
                if(dir.startswith("examples")):
                    dir_path=os.path.join(r,dir)    
                    dst_path=os.path.join(dst,r.split('/')[-1],dir)
                
                    if os.path.isdir(dir_path):
                        copy_tree(dir_path, dst_path)

except OSError as e:
    # If the error was caused because the source wasn't a directory
    if e.errno == errno.ENOTDIR:
       shutil.copy(dir_path, dst_path)
    else:
        print('Directory not copied. Error: %s' % e)
