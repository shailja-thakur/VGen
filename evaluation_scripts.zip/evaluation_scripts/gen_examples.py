import os
import openai
import pdb
from pathlib import Path
import subprocess
import time

def complete_example(ex):

    lines = ex.split('\n')
    num_begins = 0
    num_ends = 0
    for line in lines:
        if ("begin" in line and not("//" in line) ):
            num_begins = num_begins +1
        if ("end" in line and not("//" in line) ):
            num_ends = num_ends +1
    
    end_additions = num_begins - num_ends
    if (end_additions > 0):
        for i in range(end_additions):
            #add end at the end of the file
            ex=ex+"end\n"
    
    ex=ex+"endmodule\n"

    return ex

# set the codex api key
os.environ["OPENAI_API_KEY"]=""
# to use code-davinci-002
#openai.api_key = os.environ.get("OPENAI_API_KEY") 

# to use our own tools
openai.api_key='dummy'
# arrakis
openai.api_base=''
# sg03
#openai.api_base=''
# get the prompt file paths
prompt_filepaths = []
base_dir = os.path.join(os.getcwd(),"prompts-and-testbenches/advanced5")
# r=root, d=directories, f = files
for r, d, f in os.walk(base_dir):
    for file in f:
        if (not file.startswith("tb") and not file.startswith("answer") and not file.startswith("example") and file.endswith(".v") ):
            prompt_filepaths.append(os.path.join(r, file))

# # print all filepaths for prompts
# for f in prompt_filepaths:
#     print(f)

# to pause when limit is reached
rate_limit = 0 # requests/min
ctr_requests = 0

# get the prompt for each filepath
for prompt_filepath in prompt_filepaths:
    pf = open(prompt_filepath, "r")
    file_lines = pf.readlines()
    prompt = ''.join(file_lines)
    # print(prompt)

    # get path of prompt directory
    p = Path(prompt_filepath)
    prompt_dir = p.parent

    # for each prompt, generate N examples for the range of parameters
    N=20
    max_token_length = 300
    llm = "codegen_16B" # llm is varied on the remote server, not in this script
    temp = [0.1,0.3,0.5,0.7,1]
    model='NA'
    for t in temp:

        # create the examples directory for each scenario if it does not exist
        # Note: if you want to re-generate an existing examples directory, you will have to remove the existing directory
        # You may also remove all examples by running remove_all_examples.py
        examples_dir_name = "examples-" + llm + "-tmp_" + str(t)
        examples_dir = os.path.join(prompt_dir, examples_dir_name )
        
        if not os.path.isdir(examples_dir):
            os.mkdir(examples_dir)
            print("directory "+ examples_dir+" created")

            #get completions
            completion = openai.Completion.create(
                engine='codegen', # doesn't matter
                #model='code-davinci-002',
                prompt=prompt,
                # echo=True,
                n=N,
                max_tokens=max_token_length,
                temperature=t,
                stop=["endmodule", "endmodulemodule"]
                )
            #if model == 'code-davinci-002': 
            #    ctr_requests+=1
            #    print("ctr_requests: ", ctr_requests)
            #    if(ctr_requests==rate_limit):
            #        print("pausing")
            #        # pause 60 seconds
            #        ctr_requests = 0
            #        time.sleep(60)

            # print("completion generated")
            
            #dump the json file for the completions
            filename =  "examples.json"
            with open( os.path.join(examples_dir,filename),'w' ) as fw:
                fw.write(prompt)
                fw.write(str(completion))
                print("writing json file for "+ examples_dir_name)
            fw.close()

            #create example files in examples_dir
            for j,example in enumerate(completion.choices):
                # complete example if needed e.g. adding endmodule, adding end keywords
                complete_ex = prompt + example.text
                complete_ex = complete_example(complete_ex)
                # create example file
                filename = "example"+str(j)+".v"
                with open( os.path.join(examples_dir,filename),'w' ) as fw:
                    fw.write(complete_ex)
                fw.close()

            #create a master example file with all the examples
            master_filename = "master_examples.txt"
            with open( os.path.join(examples_dir,master_filename), 'w' ) as fw:
                for j,example in enumerate(completion.choices):
                    fw.write("example-"+str(j)+": \n")
                    fw.write(prompt)    
                    fw.write(example.text)
                    fw.write("\n================================================================\n")
            fw.close()

    print("examples created for "+prompt_filepath)
